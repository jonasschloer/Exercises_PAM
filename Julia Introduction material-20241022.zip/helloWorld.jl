println("Hello World!")
course = "Particle Accelerator Physics and Modeling I"
println("Welcome to $course")
